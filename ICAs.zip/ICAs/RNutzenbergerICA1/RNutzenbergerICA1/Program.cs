﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace RNutzenbergerICA1
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();

            //////////////////////////////////////////////////////////////////////////
            //testing Categorize with ints
            //////////////////////////////////////////////////////////////////////////
            Console.WriteLine("----------------------------\nTesting Categorize....\n----------------------------");
            List<int> iNums = new List<int>(new int[] { 4, 12, 4, 3, 5, 6, 7, 6, 12 });
            
            //iterate through and display the the key and value of the categorized List(Now Dictionary)
            foreach(KeyValuePair<int, int> scan in iNums.Categorize())
            {
                Console.WriteLine($"{scan.Key:d3} x {scan.Value:d5}");
            }

            Console.WriteLine();

            //////////////////////////////////////////////////////////////////////////
            //testing Categorize with strings
            //////////////////////////////////////////////////////////////////////////
            List<string> names = new List<string>(new string[] { "Rick", "Glenn","Rick", "Carl", "Michonne", "Rick", "Glenn" });

            //iterate through and display the the key and value of the categorized List(Now Dictionary)
            foreach (KeyValuePair<string,int> scan in names.Categorize())
            {
                Console.WriteLine($"{scan.Key} x {scan.Value:d5}");
            }

            Console.WriteLine();

            //////////////////////////////////////////////////////////////////////////
            //testing Categorize with chars
            //////////////////////////////////////////////////////////////////////////
            LinkedList<char> llfloats = new LinkedList<char>();
            //fill out the list with 1000 chars from A to Z
            while(llfloats.Count < 1000)
            {
                llfloats.AddLast((char)rnd.Next('A', 'Z' + 1));
            }

            //iterate through and display the the key and value of the categorized List(Now Dictionary)
            foreach (KeyValuePair<char, int> scan in llfloats.Categorize())
            {
                Console.WriteLine($"{scan.Key} x {scan.Value:d5}");
            }

            Console.WriteLine();

            //////////////////////////////////////////////////////////////////////////
            //testing Categorize with a string broken up into chars
            //////////////////////////////////////////////////////////////////////////
            string testString = "This is the test string, do not panic!";

            //iterate through and display the the key and value of the categorized List(Now Dictionary)
            foreach (KeyValuePair<char, int> scan in testString.Categorize())
            {
                Console.WriteLine($"{scan.Key} x {scan.Value:d5}");
            }

            Console.WriteLine();
            //////////////////////////////////////////////////////////////////////////
            //testing Modal with the testString2
            //////////////////////////////////////////////////////////////////////////
            Console.WriteLine("----------------------------\nTesting Modal....\n----------------------------");
            string testString2 = "Testing this string out";
            //save the most popular value into a char and display
            char mostPop1 = testString2.Modal();
            Console.WriteLine(testString2);
            Console.WriteLine($"Most Popular char is... [{mostPop1}]");
            
            Console.WriteLine();

            int[] testArr = new int[] { 1, 4, 5, 7, 7, 9, 7, 4 };
            //iterate through and display the original array
            foreach(int i in testArr)
            {
                Console.Write($"{i} ");
            }
            int mostPop2 = testArr.Modal();
            Console.WriteLine($"\nMost popular: {mostPop2}\n");

            int[] testArr2 = new int[] { 1, 4, 5, 7, 4, 7, 9, 4, 7  };
            //iterate through and display the original array
            foreach (int i in testArr2)
            {
                Console.Write($"{i} ");
            }

            //save the most popular int and display
            int mostPop3 = testArr2.Modal();
            Console.WriteLine($"\nMost popular: {mostPop3}\n");

            //iterate and display the original string array
            List<string> names2 = new List<string>(new string[] { "Rick", "Glenn", "Rick", "Carl", "Michonne", "Rick", "Glenn" });
            foreach (string s in names2)
            {
                Console.Write($"{s} ");
            }
            //save the most popular string and display
            string mostPop4 = names2.Modal();
            Console.WriteLine($"\nMost popular: {mostPop4}\n");

            //////////////////////////////////////////////////////////////////////////
            //testing Shuffle with the testString3
            //////////////////////////////////////////////////////////////////////////
            Console.WriteLine("----------------------------\nTesting Shuffle....\n----------------------------");
            string testString3 = "Shuffle this string up!";
            string returnString = "";
            //shuffle the string up and add each char to the empty string
            foreach(char c in testString3.Shuffle())
            {
                returnString += c;
            }
            //display before string and the shuffled string
            Console.WriteLine(testString3);
            Console.WriteLine(returnString);

            Console.WriteLine();

            //shuffle the list of strings and display the shuffled list
            List<string> names3 = new List<string>(new string[] { "Rick", "Glenn", "Rick", "Carl", "Michonne", "Rick", "Glenn" });
            foreach (string s in names3)
            {
                Console.Write($"{s} ");
            }
            Console.WriteLine();
            foreach (string s in names3.Shuffle())
            {
                Console.Write($"{s} ");
            }
            Console.WriteLine();

            //////////////////////////////////////////////////////////////////////////
            //testing Frame 
            //////////////////////////////////////////////////////////////////////////
            Console.WriteLine("\n----------------------------\nTesting Frame....\n----------------------------");
            int[] junk = new int[] { 4, 5, 2, 5, 6, 2, 1, 8, -2 };
            //show the lowest and highest int in the array
            Console.WriteLine($"Low: {junk.Frame().low}, High: {junk.Frame().high}");

            //////////////////////////////////////////////////////////////////////////
            //testing Stack
            //////////////////////////////////////////////////////////////////////////
            Console.WriteLine("\n----------------------------\nTesting Stack....\n----------------------------");
            derivedStack<string> testStack = new derivedStack<string>();
            testStack.Push("a");
            testStack.Push("b");
            testStack.Push("c");
            testStack.Push("d");
            testStack.Push("e");

            //try test to get the index correctly
            try
            {
                Console.WriteLine($"{testStack[1]}");
            }
            //catch if the index is out of range
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            //try test to get the key correctly
            try
            {
                Console.WriteLine($"{testStack["c"]}");
            }
            //catch if the key is not in the stack
            catch
            {
                Console.WriteLine("Key is not in the stack");
            }

            //try test to get the index correctly
            try
            {
                Console.WriteLine($"{testStack[8]}");
            }
            //catch if the index is out of range
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            //try test to get the key correctly
            try
            {
                Console.WriteLine($"{testStack["z"]}");
            }
            //catch if the key is not in the stack
            catch
            {
                Console.WriteLine("Key is not in the stack");
            }




            Console.WriteLine("\n----------------------------\nTesting Stack....\n----------------------------");
            //Add a bunch if Balls to the stack
            derivedStack<Ball> testStack2 = new derivedStack<Ball>();
            Ball snake1 = new Ball(new PointF(10,50), Color.Red);
            Ball blob1 = new Ball(new PointF(234, 431), Color.DarkGray);
            Ball snake2 = new Ball(new PointF(772, 79), Color.DarkSeaGreen);
            Ball blob2 = new Ball(new PointF(72, 29), Color.Chocolate);
            Ball snake3 = new Ball(new PointF(272, 279), Color.Green);
            Ball blob3 = new Ball(new PointF(623, 347), Color.Red);
            testStack2.Push(snake1);
            testStack2.Push(blob1);
            testStack2.Push(snake2);
            testStack2.Push(blob2);
            testStack2.Push(snake3);
            testStack2.Push(blob3);

            //use the indexes creating in the derived stack to show key and index of where the key is
            Console.WriteLine($"{testStack2[1].BallColor}");
            Console.WriteLine($"{testStack2[snake1]}");
            Console.WriteLine($"{testStack2[4].BallColor}");
            Console.WriteLine($"{testStack2[blob1]}");
            
            Console.ReadKey();
        }
    }

    public static class Extensions
    {
        static Random rnd = new Random();
        /// <summary>
        /// Accepts an IEnumerable and sorts the keys, returns a sorted dictionary
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sourceList"></param>
        /// <returns></returns>
        public static Dictionary<T, int> Categorize<T>(this IEnumerable<T> sourceList) where T : IComparable
        {
            //make a dictionary and iterate through the collection
            Dictionary<T, int> newDict = new Dictionary<T, int>();
            foreach(T key in sourceList)
            {
                //if the dictionary contains the key , then increment
                if (newDict.ContainsKey(key))
                {
                    newDict[key]++;
                }
                //otherwise add the new key
                else
                {
                    newDict.Add(key, 1);
                }
            }

            //return the sorted dictionary
            return newDict.OrderBy((key) => key.Key).ToDictionary(k => k.Key, v => v.Value);
            
        }

        /// <summary>
        /// Returns the most frequent key in the collection
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <returns></returns>
        public static T Modal<T>(this IEnumerable<T> collection) where T : IComparable
        {
            //assign the dictionary to the catagorized collection
            Dictionary<T, int> output = collection.Categorize();

            //get the max value of the categorized dictionary
            int iMax = output.Max(kvp => kvp.Value);
            //return the last instance of the specified key and value
            return collection.Last(x => output.Contains(new KeyValuePair<T, int>(x, iMax)));

        }

        /// <summary>
        /// Fisher Yates shuffle on an IEnumerable collection
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <returns></returns>
        public static IEnumerable<T> Shuffle<T>(this IEnumerable<T> collection) where T : IComparable
        {
            //Use a list as an easy type to use to sort the shuffle out
            List<T> output = new List<T>(collection);
            int i = output.Count;
            //simple fisher yates, get a random index and swap
            while (i > 1)
            {
                i--;
                int j = rnd.Next(i + 1);
                T temp = output[j];
                output[j] = output[i];
                output[i] = temp;
            }
            return output;
        }

        /// <summary>
        /// Returns the lowest and highest values of an IEnumerable collection
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <returns></returns>
        public static (T low, T high) Frame<T>(this IEnumerable<T> collection) where T : IComparable
        {
            //categorize the collection and return the first and last keys. 
            //That will give us the lowest and highest keys
            Dictionary<T, int> temp = collection.Categorize();
            return (temp.Keys.First(), temp.Keys.Last());

        }
    }
    /// <summary>
    /// derived from Stack
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class derivedStack<T> : Stack<T> where T : IComparable
    {
        /// <summary>
        /// returns the key at the specified index
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public T this[int index]
        {
            get
            {
                if (index >= Count)
                {
                    throw new IndexOutOfRangeException("Index is out of range");
                }
                return this.Categorize().Keys.ToList()[index];
            }
        }

        /// <summary>
        /// returns the index at the specified key
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public int this[T key]
        {
            get
            {
                if (!this.Categorize().ContainsKey(key))
                {
                    throw new ArgumentException("Key not in the stack");
                }
                return this.Categorize()[key];
            }
        }
    }
    
}
