﻿namespace RNutzenbergerMultiDrawClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UI_StripBar = new System.Windows.Forms.StatusStrip();
            this._ssConnect = new System.Windows.Forms.ToolStripStatusLabel();
            this._ssColour = new System.Windows.Forms.ToolStripStatusLabel();
            this._ssThickness = new System.Windows.Forms.ToolStripStatusLabel();
            this._ssFrames = new System.Windows.Forms.ToolStripStatusLabel();
            this._ssFragments = new System.Windows.Forms.ToolStripStatusLabel();
            this._ssDestack = new System.Windows.Forms.ToolStripStatusLabel();
            this._ssBytes = new System.Windows.Forms.ToolStripStatusLabel();
            this.UI_StripBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // UI_StripBar
            // 
            this.UI_StripBar.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.UI_StripBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._ssConnect,
            this._ssColour,
            this._ssThickness,
            this._ssFrames,
            this._ssFragments,
            this._ssDestack,
            this._ssBytes});
            this.UI_StripBar.Location = new System.Drawing.Point(0, 792);
            this.UI_StripBar.Name = "UI_StripBar";
            this.UI_StripBar.Size = new System.Drawing.Size(1401, 32);
            this.UI_StripBar.SizingGrip = false;
            this.UI_StripBar.Stretch = false;
            this.UI_StripBar.TabIndex = 0;
            this.UI_StripBar.Text = "statusStrip1";
            // 
            // _ssConnect
            // 
            this._ssConnect.Name = "_ssConnect";
            this._ssConnect.Size = new System.Drawing.Size(198, 25);
            this._ssConnect.Spring = true;
            this._ssConnect.Text = "Connect";
            // 
            // _ssColour
            // 
            this._ssColour.Name = "_ssColour";
            this._ssColour.Size = new System.Drawing.Size(198, 25);
            this._ssColour.Spring = true;
            this._ssColour.Text = "Colour";
            // 
            // _ssThickness
            // 
            this._ssThickness.Name = "_ssThickness";
            this._ssThickness.Size = new System.Drawing.Size(198, 25);
            this._ssThickness.Spring = true;
            this._ssThickness.Text = "Thickness";
            // 
            // _ssFrames
            // 
            this._ssFrames.Name = "_ssFrames";
            this._ssFrames.Size = new System.Drawing.Size(198, 25);
            this._ssFrames.Spring = true;
            this._ssFrames.Text = "Frames RXed:";
            // 
            // _ssFragments
            // 
            this._ssFragments.Name = "_ssFragments";
            this._ssFragments.Size = new System.Drawing.Size(198, 25);
            this._ssFragments.Spring = true;
            this._ssFragments.Text = "Fragments: ";
            // 
            // _ssDestack
            // 
            this._ssDestack.Name = "_ssDestack";
            this._ssDestack.Size = new System.Drawing.Size(198, 25);
            this._ssDestack.Spring = true;
            this._ssDestack.Text = "Destack Avg:";
            // 
            // _ssBytes
            // 
            this._ssBytes.Name = "_ssBytes";
            this._ssBytes.Size = new System.Drawing.Size(198, 25);
            this._ssBytes.Spring = true;
            this._ssBytes.Text = "Bytes RXed:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1401, 824);
            this.Controls.Add(this.UI_StripBar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.UI_StripBar.ResumeLayout(false);
            this.UI_StripBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip UI_StripBar;
        private System.Windows.Forms.ToolStripStatusLabel _ssConnect;
        private System.Windows.Forms.ToolStripStatusLabel _ssColour;
        private System.Windows.Forms.ToolStripStatusLabel _ssThickness;
        private System.Windows.Forms.ToolStripStatusLabel _ssFrames;
        private System.Windows.Forms.ToolStripStatusLabel _ssFragments;
        private System.Windows.Forms.ToolStripStatusLabel _ssDestack;
        private System.Windows.Forms.ToolStripStatusLabel _ssBytes;
    }
}

