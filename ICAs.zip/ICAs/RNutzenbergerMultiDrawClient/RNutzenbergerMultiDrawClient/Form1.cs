﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RNutzenbergerMultiDrawClient
{
    public partial class Form1 : Form
    {
        string IP = "bits.net.nait.ca";
        int PORT = 1666;
        public Form1()
        {
            InitializeComponent();
        }
    }
}
